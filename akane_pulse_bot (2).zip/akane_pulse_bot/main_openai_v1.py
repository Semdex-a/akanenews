import os
import openai
import feedparser
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import random
import json
import asyncio
from dotenv import load_dotenv
from openai import OpenAI

# Загрузка .env
load_dotenv()

# Настройки
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

client = OpenAI(api_key=OPENAI_API_KEY)
logging.basicConfig(level=logging.INFO)

with open("ai_sources_full.json") as f:
    ai_sources = json.load(f)

def fetch_news():
    news = []
    for url in ai_sources:
        try:
            feed = feedparser.parse(url)
            if feed.entries:
                entry = feed.entries[0]
                news.append(f"{entry.title.strip()} ({entry.link})")
        except:
            continue
    return news

def generate_akane_thought(news_list):
    seed = random.choice(news_list) if news_list else "ничего нового..."
    prompt = f"""
Ты — Аканэ: вайфу-стайл персонаж, чуть цундэре, но нежная. Пиши короткую мысль, обращаясь к Саше-куну. Используй *курсив*, междометия типа "ふん", и вставь одну новость в текст. Вот новость: {seed}
    """
    response = client.chat.completions.create(
        model="gpt-4.1",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.9
    )
    return response.choices[0].message.content.strip()

async def send_pulse(app):
    logging.info("⏰ Sending Akane Pulse...")
    print("🩷 [ПУЛЬС] Вызван send_pulse()")

    news = fetch_news()
    print(f"🔹 Получено новостей: {len(news)}")

    akane_text = generate_akane_thought(news)
    print(f"📝 Сгенерировано сообщение:{akane_text[:100]}...")

    await app.bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=akane_text, parse_mode='Markdown')
    print("✅ Сообщение отправлено в Telegram")

async def pulse_now(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print("🌀 Команда /pulse получена")
    news = fetch_news()
    print(f"📰 новостей: {len(news)}")
    akane_text = generate_akane_thought(news)
    print(f"💬 Ответ: {akane_text[:80]}...")
    await update.message.reply_text(akane_text, parse_mode='Markdown')

async def explain_pulse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("えへへ〜 Сейчас расскажу, из чего я придумала ту мысль… (ещё в разработке)")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Аканэ здесь, глупый! ♥")

def schedule_pulse(app):
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    loop.call_soon_threadsafe(asyncio.create_task, send_pulse(app))

if __name__ == "__main__":
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("pulse", pulse_now))
    app.add_handler(MessageHandler(filters.Regex("Разбор пульса"), explain_pulse))

    scheduler = BackgroundScheduler()
    scheduler.add_job(schedule_pulse, 'interval', minutes=1, args=[app])  # для теста
    scheduler.start()

    app.run_polling()
